To compile with C++:

    FC=lfortran FFLAGS="--backend=cpp" cmake .
