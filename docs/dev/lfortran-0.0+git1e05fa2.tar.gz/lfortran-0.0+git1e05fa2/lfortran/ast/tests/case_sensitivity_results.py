results = [
    ('Declaration', (1, 1), [('decl', 'x', 'integer', [], [])]),
    ('Declaration', (1, 1), [('decl', 'x', 'integer', [], [])]),
    ('Declaration', (1, 1), [('decl', 'x', 'integer', [], [])]),
    ('Declaration', (1, 1), [('decl', 'c', 'integer', [], [('Attribute', 'dimension(9,10)', [])])]),
    ('Declaration', (1, 1), [('decl', 'e', 'integer', [], [('Attribute', 'dimension(:,:)', []), ('Attribute', 'intent', [('attribute_arg', 'in')])])]),
    ('Declaration', (1, 1), [('decl', 'i', 'integer', [], [])]),
    ('Declaration', (1, 1), [('decl', 'a', 'real', [], [])]),
    ('Declaration', (1, 1), [('decl', 'a', 'real', [], [])]),
    ('Declaration', (1, 1), [('decl', 'a', 'real', [('dimension', None, None), ('dimension', None, None)], [('Attribute', 'allocatable', [])])]),
    ('Declaration', (1, 1), [('decl', 'c', 'character', [], [])]),
    ('Declaration', (1, 1), [('decl', 'x', 'type', [], [('Attribute', 'intent', [('attribute_arg', 'inout')])]), ('decl', 'y', 'type', [], [('Attribute', 'intent', [('attribute_arg', 'inout')])])]),
]
