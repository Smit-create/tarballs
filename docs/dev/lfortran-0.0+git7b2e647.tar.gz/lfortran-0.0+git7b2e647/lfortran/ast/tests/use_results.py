results = [
    ('Use', (1, 1), 'b', []),
    ('Use', (1, 1), 'a', [('UseSymbol', 'b', None), ('UseSymbol', 'c', None)]),
    ('Use', (1, 1), 'a', [('UseSymbol', 'x', 'b'), ('UseSymbol', 'c', None), ('UseSymbol', 'd', 'a')]),
]
