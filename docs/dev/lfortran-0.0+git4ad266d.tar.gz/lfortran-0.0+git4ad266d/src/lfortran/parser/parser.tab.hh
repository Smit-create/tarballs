/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NAME = 258,
    TK_DEF_OP = 259,
    TK_INTEGER = 260,
    TK_REAL = 261,
    TK_NEWLINE = 262,
    TK_STRING = 263,
    TK_DBL_DOT = 264,
    TK_DBL_COLON = 265,
    TK_POW = 266,
    TK_CONCAT = 267,
    TK_ARROW = 268,
    TK_EQ = 269,
    TK_NE = 270,
    TK_LT = 271,
    TK_LE = 272,
    TK_GT = 273,
    TK_GE = 274,
    TK_NOT = 275,
    TK_AND = 276,
    TK_OR = 277,
    TK_EQV = 278,
    TK_NEQV = 279,
    TK_TRUE = 280,
    TK_FALSE = 281,
    KW_ABSTRACT = 282,
    KW_ALL = 283,
    KW_ALLOCATABLE = 284,
    KW_ALLOCATE = 285,
    KW_ASSIGNMENT = 286,
    KW_ASSOCIATE = 287,
    KW_ASYNCHRONOUS = 288,
    KW_BACKSPACE = 289,
    KW_BIND = 290,
    KW_BLOCK = 291,
    KW_CALL = 292,
    KW_CASE = 293,
    KW_CHARACTER = 294,
    KW_CLASS = 295,
    KW_CLOSE = 296,
    KW_CODIMENSION = 297,
    KW_COMMON = 298,
    KW_COMPLEX = 299,
    KW_CONCURRENT = 300,
    KW_CONTAINS = 301,
    KW_CONTIGUOUS = 302,
    KW_CONTINUE = 303,
    KW_CRITICAL = 304,
    KW_CYCLE = 305,
    KW_DATA = 306,
    KW_DEALLOCATE = 307,
    KW_DEFAULT = 308,
    KW_DEFERRED = 309,
    KW_DIMENSION = 310,
    KW_DO = 311,
    KW_DOWHILE = 312,
    KW_DOUBLE = 313,
    KW_ELEMENTAL = 314,
    KW_ELSE = 315,
    KW_END = 316,
    KW_END_IF = 317,
    KW_ENDIF = 318,
    KW_END_DO = 319,
    KW_ENDDO = 320,
    KW_ENTRY = 321,
    KW_ENUM = 322,
    KW_ENUMERATOR = 323,
    KW_EQUIVALENCE = 324,
    KW_ERRMSG = 325,
    KW_ERROR = 326,
    KW_EXIT = 327,
    KW_EXTENDS = 328,
    KW_EXTERNAL = 329,
    KW_FILE = 330,
    KW_FINAL = 331,
    KW_FLUSH = 332,
    KW_FORALL = 333,
    KW_FORMAT = 334,
    KW_FORMATTED = 335,
    KW_FUNCTION = 336,
    KW_GENERIC = 337,
    KW_GO = 338,
    KW_IF = 339,
    KW_IMPLICIT = 340,
    KW_IMPORT = 341,
    KW_IMPURE = 342,
    KW_IN = 343,
    KW_INCLUDE = 344,
    KW_INOUT = 345,
    KW_INQUIRE = 346,
    KW_INTEGER = 347,
    KW_INTENT = 348,
    KW_INTERFACE = 349,
    KW_INTRINSIC = 350,
    KW_IS = 351,
    KW_KIND = 352,
    KW_LEN = 353,
    KW_LOCAL = 354,
    KW_LOCAL_INIT = 355,
    KW_LOGICAL = 356,
    KW_MODULE = 357,
    KW_MOLD = 358,
    KW_NAME = 359,
    KW_NAMELIST = 360,
    KW_NOPASS = 361,
    KW_NON_INTRINSIC = 362,
    KW_NON_OVERRIDABLE = 363,
    KW_NON_RECURSIVE = 364,
    KW_NONE = 365,
    KW_NULLIFY = 366,
    KW_ONLY = 367,
    KW_OPEN = 368,
    KW_OPERATOR = 369,
    KW_OPTIONAL = 370,
    KW_OUT = 371,
    KW_PARAMETER = 372,
    KW_PASS = 373,
    KW_POINTER = 374,
    KW_PRECISION = 375,
    KW_PRINT = 376,
    KW_PRIVATE = 377,
    KW_PROCEDURE = 378,
    KW_PROGRAM = 379,
    KW_PROTECTED = 380,
    KW_PUBLIC = 381,
    KW_PURE = 382,
    KW_QUIET = 383,
    KW_RANK = 384,
    KW_READ = 385,
    KW_REAL = 386,
    KW_RECURSIVE = 387,
    KW_RESULT = 388,
    KW_RETURN = 389,
    KW_REWIND = 390,
    KW_SAVE = 391,
    KW_SELECT = 392,
    KW_SEQUENCE = 393,
    KW_SHARED = 394,
    KW_SOURCE = 395,
    KW_STAT = 396,
    KW_STOP = 397,
    KW_SUBMODULE = 398,
    KW_SUBROUTINE = 399,
    KW_TARGET = 400,
    KW_TEAM = 401,
    KW_TEAM_NUMBER = 402,
    KW_THEN = 403,
    KW_TO = 404,
    KW_TYPE = 405,
    KW_UNFORMATTED = 406,
    KW_USE = 407,
    KW_VALUE = 408,
    KW_VOLATILE = 409,
    KW_WHERE = 410,
    KW_WHILE = 411,
    KW_WRITE = 412
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
