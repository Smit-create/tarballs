/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_REAL = 262,
    TK_BOZ_CONSTANT = 263,
    TK_PLUS = 264,
    TK_MINUS = 265,
    TK_STAR = 266,
    TK_SLASH = 267,
    TK_COLON = 268,
    TK_SEMICOLON = 269,
    TK_COMMA = 270,
    TK_EQUAL = 271,
    TK_LPAREN = 272,
    TK_RPAREN = 273,
    TK_LBRACKET = 274,
    TK_RBRACKET = 275,
    TK_PERCENT = 276,
    TK_VBAR = 277,
    TK_STRING = 278,
    TK_COMMENT = 279,
    TK_DBL_DOT = 280,
    TK_DBL_COLON = 281,
    TK_POW = 282,
    TK_CONCAT = 283,
    TK_ARROW = 284,
    TK_EQ = 285,
    TK_NE = 286,
    TK_LT = 287,
    TK_LE = 288,
    TK_GT = 289,
    TK_GE = 290,
    TK_NOT = 291,
    TK_AND = 292,
    TK_OR = 293,
    TK_EQV = 294,
    TK_NEQV = 295,
    TK_TRUE = 296,
    TK_FALSE = 297,
    KW_ABSTRACT = 298,
    KW_ALL = 299,
    KW_ALLOCATABLE = 300,
    KW_ALLOCATE = 301,
    KW_ASSIGNMENT = 302,
    KW_ASSOCIATE = 303,
    KW_ASYNCHRONOUS = 304,
    KW_BACKSPACE = 305,
    KW_BIND = 306,
    KW_BLOCK = 307,
    KW_CALL = 308,
    KW_CASE = 309,
    KW_CHARACTER = 310,
    KW_CLASS = 311,
    KW_CLOSE = 312,
    KW_CODIMENSION = 313,
    KW_COMMON = 314,
    KW_COMPLEX = 315,
    KW_CONCURRENT = 316,
    KW_CONTAINS = 317,
    KW_CONTIGUOUS = 318,
    KW_CONTINUE = 319,
    KW_CRITICAL = 320,
    KW_CYCLE = 321,
    KW_DATA = 322,
    KW_DEALLOCATE = 323,
    KW_DEFAULT = 324,
    KW_DEFERRED = 325,
    KW_DIMENSION = 326,
    KW_DO = 327,
    KW_DOWHILE = 328,
    KW_DOUBLE = 329,
    KW_ELEMENTAL = 330,
    KW_ELSE = 331,
    KW_ELSEIF = 332,
    KW_ELSEWHERE = 333,
    KW_END = 334,
    KW_END_IF = 335,
    KW_ENDIF = 336,
    KW_END_FORALL = 337,
    KW_ENDFORALL = 338,
    KW_END_DO = 339,
    KW_ENDDO = 340,
    KW_END_WHERE = 341,
    KW_ENDWHERE = 342,
    KW_ENTRY = 343,
    KW_ENUM = 344,
    KW_ENUMERATOR = 345,
    KW_EQUIVALENCE = 346,
    KW_ERRMSG = 347,
    KW_ERROR = 348,
    KW_EXIT = 349,
    KW_EXTENDS = 350,
    KW_EXTERNAL = 351,
    KW_FILE = 352,
    KW_FINAL = 353,
    KW_FLUSH = 354,
    KW_FORALL = 355,
    KW_FORMAT = 356,
    KW_FORMATTED = 357,
    KW_FUNCTION = 358,
    KW_GENERIC = 359,
    KW_GO = 360,
    KW_IF = 361,
    KW_IMPLICIT = 362,
    KW_IMPORT = 363,
    KW_IMPURE = 364,
    KW_IN = 365,
    KW_INCLUDE = 366,
    KW_INOUT = 367,
    KW_INQUIRE = 368,
    KW_INTEGER = 369,
    KW_INTENT = 370,
    KW_INTERFACE = 371,
    KW_INTRINSIC = 372,
    KW_IS = 373,
    KW_KIND = 374,
    KW_LEN = 375,
    KW_LOCAL = 376,
    KW_LOCAL_INIT = 377,
    KW_LOGICAL = 378,
    KW_MODULE = 379,
    KW_MOLD = 380,
    KW_NAME = 381,
    KW_NAMELIST = 382,
    KW_NOPASS = 383,
    KW_NON_INTRINSIC = 384,
    KW_NON_OVERRIDABLE = 385,
    KW_NON_RECURSIVE = 386,
    KW_NONE = 387,
    KW_NULLIFY = 388,
    KW_ONLY = 389,
    KW_OPEN = 390,
    KW_OPERATOR = 391,
    KW_OPTIONAL = 392,
    KW_OUT = 393,
    KW_PARAMETER = 394,
    KW_PASS = 395,
    KW_POINTER = 396,
    KW_PRECISION = 397,
    KW_PRINT = 398,
    KW_PRIVATE = 399,
    KW_PROCEDURE = 400,
    KW_PROGRAM = 401,
    KW_PROTECTED = 402,
    KW_PUBLIC = 403,
    KW_PURE = 404,
    KW_QUIET = 405,
    KW_RANK = 406,
    KW_READ = 407,
    KW_REAL = 408,
    KW_RECURSIVE = 409,
    KW_REDUCE = 410,
    KW_RESULT = 411,
    KW_RETURN = 412,
    KW_REWIND = 413,
    KW_SAVE = 414,
    KW_SELECT = 415,
    KW_SEQUENCE = 416,
    KW_SHARED = 417,
    KW_SOURCE = 418,
    KW_STAT = 419,
    KW_STOP = 420,
    KW_SUBMODULE = 421,
    KW_SUBROUTINE = 422,
    KW_TARGET = 423,
    KW_TEAM = 424,
    KW_TEAM_NUMBER = 425,
    KW_THEN = 426,
    KW_TO = 427,
    KW_TYPE = 428,
    KW_UNFORMATTED = 429,
    KW_USE = 430,
    KW_VALUE = 431,
    KW_VOLATILE = 432,
    KW_WHERE = 433,
    KW_WHILE = 434,
    KW_WRITE = 435,
    UMINUS = 436
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
