/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2019 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 24 "parser.yy" /* yacc.c:1921  */

#include <lfortran/parser/parser.h>

#line 52 "parser.tab.hh" /* yacc.c:1921  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NAME = 258,
    TK_DEF_OP = 259,
    TK_INTEGER = 260,
    TK_REAL = 261,
    TK_NEWLINE = 262,
    TK_STRING = 263,
    TK_DBL_DOT = 264,
    TK_DBL_COLON = 265,
    TK_POW = 266,
    TK_CONCAT = 267,
    TK_ARROW = 268,
    TK_EQ = 269,
    TK_NE = 270,
    TK_LT = 271,
    TK_LE = 272,
    TK_GT = 273,
    TK_GE = 274,
    TK_NOT = 275,
    TK_AND = 276,
    TK_OR = 277,
    TK_EQV = 278,
    TK_NEQV = 279,
    TK_TRUE = 280,
    TK_FALSE = 281,
    KW_ABSTRACT = 282,
    KW_ALL = 283,
    KW_ALLOCATABLE = 284,
    KW_ALLOCATE = 285,
    KW_ASSIGNMENT = 286,
    KW_ASSOCIATE = 287,
    KW_ASYNCHRONOUS = 288,
    KW_BACKSPACE = 289,
    KW_BIND = 290,
    KW_BLOCK = 291,
    KW_CALL = 292,
    KW_CASE = 293,
    KW_CHARACTER = 294,
    KW_CLASS = 295,
    KW_CLOSE = 296,
    KW_CODIMENSION = 297,
    KW_COMMON = 298,
    KW_COMPLEX = 299,
    KW_CONCURRENT = 300,
    KW_CONTAINS = 301,
    KW_CONTIGUOUS = 302,
    KW_CONTINUE = 303,
    KW_CRITICAL = 304,
    KW_CYCLE = 305,
    KW_DATA = 306,
    KW_DEALLOCATE = 307,
    KW_DEFAULT = 308,
    KW_DEFERRED = 309,
    KW_DIMENSION = 310,
    KW_DO = 311,
    KW_DOWHILE = 312,
    KW_DOUBLE = 313,
    KW_ELEMENTAL = 314,
    KW_ELSE = 315,
    KW_END = 316,
    KW_ENDIF = 317,
    KW_ENTRY = 318,
    KW_ENUM = 319,
    KW_ENUMERATOR = 320,
    KW_EQUIVALENCE = 321,
    KW_ERRMSG = 322,
    KW_ERROR = 323,
    KW_EXIT = 324,
    KW_EXTENDS = 325,
    KW_EXTERNAL = 326,
    KW_FILE = 327,
    KW_FINAL = 328,
    KW_FLUSH = 329,
    KW_FORALL = 330,
    KW_FORMAT = 331,
    KW_FORMATTED = 332,
    KW_FUNCTION = 333,
    KW_GENERIC = 334,
    KW_GO = 335,
    KW_IF = 336,
    KW_IMPLICIT = 337,
    KW_IMPORT = 338,
    KW_IMPURE = 339,
    KW_IN = 340,
    KW_INCLUDE = 341,
    KW_INOUT = 342,
    KW_INQUIRE = 343,
    KW_INTEGER = 344,
    KW_INTENT = 345,
    KW_INTERFACE = 346,
    KW_INTRINSIC = 347,
    KW_IS = 348,
    KW_KIND = 349,
    KW_LEN = 350,
    KW_LOCAL = 351,
    KW_LOCAL_INIT = 352,
    KW_LOGICAL = 353,
    KW_MODULE = 354,
    KW_MOLD = 355,
    KW_NAME = 356,
    KW_NAMELIST = 357,
    KW_NOPASS = 358,
    KW_NON_INTRINSIC = 359,
    KW_NON_OVERRIDABLE = 360,
    KW_NON_RECURSIVE = 361,
    KW_NONE = 362,
    KW_NULLIFY = 363,
    KW_ONLY = 364,
    KW_OPEN = 365,
    KW_OPERATOR = 366,
    KW_OPTIONAL = 367,
    KW_OUT = 368,
    KW_PARAMETER = 369,
    KW_PASS = 370,
    KW_POINTER = 371,
    KW_PRECISION = 372,
    KW_PRINT = 373,
    KW_PRIVATE = 374,
    KW_PROCEDURE = 375,
    KW_PROGRAM = 376,
    KW_PROTECTED = 377,
    KW_PUBLIC = 378,
    KW_PURE = 379,
    KW_QUIET = 380,
    KW_RANK = 381,
    KW_READ = 382,
    KW_REAL = 383,
    KW_RECURSIVE = 384,
    KW_RESULT = 385,
    KW_RETURN = 386,
    KW_REWIND = 387,
    KW_SAVE = 388,
    KW_SELECT = 389,
    KW_SEQUENCE = 390,
    KW_SHARED = 391,
    KW_SOURCE = 392,
    KW_STAT = 393,
    KW_STOP = 394,
    KW_SUBMODULE = 395,
    KW_SUBROUTINE = 396,
    KW_TARGET = 397,
    KW_TEAM = 398,
    KW_TEAM_NUMBER = 399,
    KW_THEN = 400,
    KW_TO = 401,
    KW_TYPE = 402,
    KW_UNFORMATTED = 403,
    KW_USE = 404,
    KW_VALUE = 405,
    KW_VOLATILE = 406,
    KW_WHERE = 407,
    KW_WHILE = 408,
    KW_WRITE = 409
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
