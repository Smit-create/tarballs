/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_RBRACKET_OLD = 277,
    TK_PERCENT = 278,
    TK_VBAR = 279,
    TK_STRING = 280,
    TK_COMMENT = 281,
    TK_EOLCOMMENT = 282,
    TK_DBL_DOT = 283,
    TK_DBL_COLON = 284,
    TK_POW = 285,
    TK_CONCAT = 286,
    TK_ARROW = 287,
    TK_EQ = 288,
    TK_NE = 289,
    TK_LT = 290,
    TK_LE = 291,
    TK_GT = 292,
    TK_GE = 293,
    TK_NOT = 294,
    TK_AND = 295,
    TK_OR = 296,
    TK_EQV = 297,
    TK_NEQV = 298,
    TK_TRUE = 299,
    TK_FALSE = 300,
    TK_FORMAT = 301,
    KW_ABSTRACT = 302,
    KW_ALL = 303,
    KW_ALLOCATABLE = 304,
    KW_ALLOCATE = 305,
    KW_ASSIGN = 306,
    KW_ASSIGNMENT = 307,
    KW_ASSOCIATE = 308,
    KW_ASYNCHRONOUS = 309,
    KW_BACKSPACE = 310,
    KW_BIND = 311,
    KW_BLOCK = 312,
    KW_CALL = 313,
    KW_CASE = 314,
    KW_CHARACTER = 315,
    KW_CLASS = 316,
    KW_CLOSE = 317,
    KW_CODIMENSION = 318,
    KW_COMMON = 319,
    KW_COMPLEX = 320,
    KW_CONCURRENT = 321,
    KW_CONTAINS = 322,
    KW_CONTIGUOUS = 323,
    KW_CONTINUE = 324,
    KW_CRITICAL = 325,
    KW_CYCLE = 326,
    KW_DATA = 327,
    KW_DEALLOCATE = 328,
    KW_DEFAULT = 329,
    KW_DEFERRED = 330,
    KW_DIMENSION = 331,
    KW_DO = 332,
    KW_DOWHILE = 333,
    KW_DOUBLE = 334,
    KW_DOUBLE_PRECISION = 335,
    KW_ELEMENTAL = 336,
    KW_ELSE = 337,
    KW_ELSEIF = 338,
    KW_ELSEWHERE = 339,
    KW_END = 340,
    KW_END_PROGRAM = 341,
    KW_ENDPROGRAM = 342,
    KW_END_MODULE = 343,
    KW_ENDMODULE = 344,
    KW_END_SUBMODULE = 345,
    KW_ENDSUBMODULE = 346,
    KW_END_BLOCK = 347,
    KW_ENDBLOCK = 348,
    KW_END_BLOCK_DATA = 349,
    KW_ENDBLOCKDATA = 350,
    KW_END_SUBROUTINE = 351,
    KW_ENDSUBROUTINE = 352,
    KW_END_FUNCTION = 353,
    KW_ENDFUNCTION = 354,
    KW_END_PROCEDURE = 355,
    KW_ENDPROCEDURE = 356,
    KW_END_ENUM = 357,
    KW_ENDENUM = 358,
    KW_END_SELECT = 359,
    KW_ENDSELECT = 360,
    KW_END_IF = 361,
    KW_ENDIF = 362,
    KW_END_INTERFACE = 363,
    KW_ENDINTERFACE = 364,
    KW_END_TYPE = 365,
    KW_ENDTYPE = 366,
    KW_END_ASSOCIATE = 367,
    KW_ENDASSOCIATE = 368,
    KW_END_FORALL = 369,
    KW_ENDFORALL = 370,
    KW_END_DO = 371,
    KW_ENDDO = 372,
    KW_END_WHERE = 373,
    KW_ENDWHERE = 374,
    KW_END_CRITICAL = 375,
    KW_ENDCRITICAL = 376,
    KW_END_FILE = 377,
    KW_ENDFILE = 378,
    KW_ENTRY = 379,
    KW_ENUM = 380,
    KW_ENUMERATOR = 381,
    KW_EQUIVALENCE = 382,
    KW_ERRMSG = 383,
    KW_ERROR = 384,
    KW_EVENT = 385,
    KW_EXIT = 386,
    KW_EXTENDS = 387,
    KW_EXTERNAL = 388,
    KW_FILE = 389,
    KW_FINAL = 390,
    KW_FLUSH = 391,
    KW_FORALL = 392,
    KW_FORMATTED = 393,
    KW_FUNCTION = 394,
    KW_GENERIC = 395,
    KW_GO = 396,
    KW_GOTO = 397,
    KW_IF = 398,
    KW_IMPLICIT = 399,
    KW_IMPORT = 400,
    KW_IMPURE = 401,
    KW_IN = 402,
    KW_INCLUDE = 403,
    KW_INOUT = 404,
    KW_IN_OUT = 405,
    KW_INQUIRE = 406,
    KW_INTEGER = 407,
    KW_INTENT = 408,
    KW_INTERFACE = 409,
    KW_INTRINSIC = 410,
    KW_IS = 411,
    KW_KIND = 412,
    KW_LEN = 413,
    KW_LOCAL = 414,
    KW_LOCAL_INIT = 415,
    KW_LOGICAL = 416,
    KW_MODULE = 417,
    KW_MOLD = 418,
    KW_NAME = 419,
    KW_NAMELIST = 420,
    KW_NOPASS = 421,
    KW_NON_INTRINSIC = 422,
    KW_NON_OVERRIDABLE = 423,
    KW_NON_RECURSIVE = 424,
    KW_NONE = 425,
    KW_NULLIFY = 426,
    KW_ONLY = 427,
    KW_OPEN = 428,
    KW_OPERATOR = 429,
    KW_OPTIONAL = 430,
    KW_OUT = 431,
    KW_PARAMETER = 432,
    KW_PASS = 433,
    KW_POINTER = 434,
    KW_POST = 435,
    KW_PRECISION = 436,
    KW_PRINT = 437,
    KW_PRIVATE = 438,
    KW_PROCEDURE = 439,
    KW_PROGRAM = 440,
    KW_PROTECTED = 441,
    KW_PUBLIC = 442,
    KW_PURE = 443,
    KW_QUIET = 444,
    KW_RANK = 445,
    KW_READ = 446,
    KW_REAL = 447,
    KW_RECURSIVE = 448,
    KW_REDUCE = 449,
    KW_RESULT = 450,
    KW_RETURN = 451,
    KW_REWIND = 452,
    KW_SAVE = 453,
    KW_SELECT = 454,
    KW_SELECT_CASE = 455,
    KW_SELECT_RANK = 456,
    KW_SELECT_TYPE = 457,
    KW_SEQUENCE = 458,
    KW_SHARED = 459,
    KW_SOURCE = 460,
    KW_STAT = 461,
    KW_STOP = 462,
    KW_SUBMODULE = 463,
    KW_SUBROUTINE = 464,
    KW_SYNC = 465,
    KW_TARGET = 466,
    KW_TEAM = 467,
    KW_TEAM_NUMBER = 468,
    KW_THEN = 469,
    KW_TO = 470,
    KW_TYPE = 471,
    KW_UNFORMATTED = 472,
    KW_USE = 473,
    KW_VALUE = 474,
    KW_VOLATILE = 475,
    KW_WAIT = 476,
    KW_WHERE = 477,
    KW_WHILE = 478,
    KW_WRITE = 479,
    UMINUS = 480
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
