/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_RBRACKET_OLD = 277,
    TK_PERCENT = 278,
    TK_VBAR = 279,
    TK_STRING = 280,
    TK_COMMENT = 281,
    TK_DBL_DOT = 282,
    TK_DBL_COLON = 283,
    TK_POW = 284,
    TK_CONCAT = 285,
    TK_ARROW = 286,
    TK_EQ = 287,
    TK_NE = 288,
    TK_LT = 289,
    TK_LE = 290,
    TK_GT = 291,
    TK_GE = 292,
    TK_NOT = 293,
    TK_AND = 294,
    TK_OR = 295,
    TK_EQV = 296,
    TK_NEQV = 297,
    TK_TRUE = 298,
    TK_FALSE = 299,
    KW_ABSTRACT = 300,
    KW_ALL = 301,
    KW_ALLOCATABLE = 302,
    KW_ALLOCATE = 303,
    KW_ASSIGNMENT = 304,
    KW_ASSOCIATE = 305,
    KW_ASYNCHRONOUS = 306,
    KW_BACKSPACE = 307,
    KW_BIND = 308,
    KW_BLOCK = 309,
    KW_CALL = 310,
    KW_CASE = 311,
    KW_CHARACTER = 312,
    KW_CLASS = 313,
    KW_CLOSE = 314,
    KW_CODIMENSION = 315,
    KW_COMMON = 316,
    KW_COMPLEX = 317,
    KW_CONCURRENT = 318,
    KW_CONTAINS = 319,
    KW_CONTIGUOUS = 320,
    KW_CONTINUE = 321,
    KW_CRITICAL = 322,
    KW_CYCLE = 323,
    KW_DATA = 324,
    KW_DEALLOCATE = 325,
    KW_DEFAULT = 326,
    KW_DEFERRED = 327,
    KW_DIMENSION = 328,
    KW_DO = 329,
    KW_DOWHILE = 330,
    KW_DOUBLE = 331,
    KW_ELEMENTAL = 332,
    KW_ELSE = 333,
    KW_ELSEIF = 334,
    KW_ELSEWHERE = 335,
    KW_END = 336,
    KW_END_IF = 337,
    KW_ENDIF = 338,
    KW_END_INTERFACE = 339,
    KW_ENDINTERFACE = 340,
    KW_END_FORALL = 341,
    KW_ENDFORALL = 342,
    KW_END_DO = 343,
    KW_ENDDO = 344,
    KW_END_WHERE = 345,
    KW_ENDWHERE = 346,
    KW_ENTRY = 347,
    KW_ENUM = 348,
    KW_ENUMERATOR = 349,
    KW_EQUIVALENCE = 350,
    KW_ERRMSG = 351,
    KW_ERROR = 352,
    KW_EXIT = 353,
    KW_EXTENDS = 354,
    KW_EXTERNAL = 355,
    KW_FILE = 356,
    KW_FINAL = 357,
    KW_FLUSH = 358,
    KW_FORALL = 359,
    KW_FORMAT = 360,
    KW_FORMATTED = 361,
    KW_FUNCTION = 362,
    KW_GENERIC = 363,
    KW_GO = 364,
    KW_IF = 365,
    KW_IMPLICIT = 366,
    KW_IMPORT = 367,
    KW_IMPURE = 368,
    KW_IN = 369,
    KW_INCLUDE = 370,
    KW_INOUT = 371,
    KW_IN_OUT = 372,
    KW_INQUIRE = 373,
    KW_INTEGER = 374,
    KW_INTENT = 375,
    KW_INTERFACE = 376,
    KW_INTRINSIC = 377,
    KW_IS = 378,
    KW_KIND = 379,
    KW_LEN = 380,
    KW_LOCAL = 381,
    KW_LOCAL_INIT = 382,
    KW_LOGICAL = 383,
    KW_MODULE = 384,
    KW_MOLD = 385,
    KW_NAME = 386,
    KW_NAMELIST = 387,
    KW_NOPASS = 388,
    KW_NON_INTRINSIC = 389,
    KW_NON_OVERRIDABLE = 390,
    KW_NON_RECURSIVE = 391,
    KW_NONE = 392,
    KW_NULLIFY = 393,
    KW_ONLY = 394,
    KW_OPEN = 395,
    KW_OPERATOR = 396,
    KW_OPTIONAL = 397,
    KW_OUT = 398,
    KW_PARAMETER = 399,
    KW_PASS = 400,
    KW_POINTER = 401,
    KW_PRECISION = 402,
    KW_PRINT = 403,
    KW_PRIVATE = 404,
    KW_PROCEDURE = 405,
    KW_PROGRAM = 406,
    KW_PROTECTED = 407,
    KW_PUBLIC = 408,
    KW_PURE = 409,
    KW_QUIET = 410,
    KW_RANK = 411,
    KW_READ = 412,
    KW_REAL = 413,
    KW_RECURSIVE = 414,
    KW_REDUCE = 415,
    KW_RESULT = 416,
    KW_RETURN = 417,
    KW_REWIND = 418,
    KW_SAVE = 419,
    KW_SELECT = 420,
    KW_SEQUENCE = 421,
    KW_SHARED = 422,
    KW_SOURCE = 423,
    KW_STAT = 424,
    KW_STOP = 425,
    KW_SUBMODULE = 426,
    KW_SUBROUTINE = 427,
    KW_TARGET = 428,
    KW_TEAM = 429,
    KW_TEAM_NUMBER = 430,
    KW_THEN = 431,
    KW_TO = 432,
    KW_TYPE = 433,
    KW_UNFORMATTED = 434,
    KW_USE = 435,
    KW_VALUE = 436,
    KW_VOLATILE = 437,
    KW_WHERE = 438,
    KW_WHILE = 439,
    KW_WRITE = 440,
    UMINUS = 441
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
