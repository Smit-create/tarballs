results = [
    ('Declaration', (1, 1), [('decl', 'x', 'integer', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'x', 'integer', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'x', 'integer', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'c', 'integer', [], [('Attribute', 'dimension(9,10)', [])], None)]),
    ('Declaration', (1, 1), [('decl', 'e', 'integer', [], [('Attribute', 'dimension(:,:)', []), ('Attribute', 'intent', [('attribute_arg', 'in')])], None)]),
    ('Declaration', (1, 1), [('decl', 'i', 'integer', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'a', 'real', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'a', 'real', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'a', 'real', [('dimension', None, None), ('dimension', None, None)], [('Attribute', 'allocatable', [])], None)]),
    ('Declaration', (1, 1), [('decl', 'c', 'character', [], [], None)]),
    ('Declaration', (1, 1), [('decl', 'x', 'type', [], [('Attribute', 'intent', [('attribute_arg', 'inout')])], None), ('decl', 'y', 'type', [], [('Attribute', 'intent', [('attribute_arg', 'inout')])], None)]),
]
