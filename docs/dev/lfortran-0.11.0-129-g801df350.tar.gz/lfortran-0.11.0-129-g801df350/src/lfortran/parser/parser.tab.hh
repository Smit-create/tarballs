/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_RBRACKET_OLD = 277,
    TK_PERCENT = 278,
    TK_VBAR = 279,
    TK_STRING = 280,
    TK_COMMENT = 281,
    TK_DBL_DOT = 282,
    TK_DBL_COLON = 283,
    TK_POW = 284,
    TK_CONCAT = 285,
    TK_ARROW = 286,
    TK_EQ = 287,
    TK_NE = 288,
    TK_LT = 289,
    TK_LE = 290,
    TK_GT = 291,
    TK_GE = 292,
    TK_NOT = 293,
    TK_AND = 294,
    TK_OR = 295,
    TK_EQV = 296,
    TK_NEQV = 297,
    TK_TRUE = 298,
    TK_FALSE = 299,
    TK_FORMAT = 300,
    KW_ABSTRACT = 301,
    KW_ALL = 302,
    KW_ALLOCATABLE = 303,
    KW_ALLOCATE = 304,
    KW_ASSIGN = 305,
    KW_ASSIGNMENT = 306,
    KW_ASSOCIATE = 307,
    KW_ASYNCHRONOUS = 308,
    KW_BACKSPACE = 309,
    KW_BIND = 310,
    KW_BLOCK = 311,
    KW_CALL = 312,
    KW_CASE = 313,
    KW_CHARACTER = 314,
    KW_CLASS = 315,
    KW_CLOSE = 316,
    KW_CODIMENSION = 317,
    KW_COMMON = 318,
    KW_COMPLEX = 319,
    KW_CONCURRENT = 320,
    KW_CONTAINS = 321,
    KW_CONTIGUOUS = 322,
    KW_CONTINUE = 323,
    KW_CRITICAL = 324,
    KW_CYCLE = 325,
    KW_DATA = 326,
    KW_DEALLOCATE = 327,
    KW_DEFAULT = 328,
    KW_DEFERRED = 329,
    KW_DIMENSION = 330,
    KW_DO = 331,
    KW_DOWHILE = 332,
    KW_DOUBLE = 333,
    KW_DOUBLE_PRECISION = 334,
    KW_ELEMENTAL = 335,
    KW_ELSE = 336,
    KW_ELSEIF = 337,
    KW_ELSEWHERE = 338,
    KW_END = 339,
    KW_END_PROGRAM = 340,
    KW_ENDPROGRAM = 341,
    KW_END_MODULE = 342,
    KW_ENDMODULE = 343,
    KW_END_SUBMODULE = 344,
    KW_ENDSUBMODULE = 345,
    KW_END_BLOCK = 346,
    KW_ENDBLOCK = 347,
    KW_END_BLOCK_DATA = 348,
    KW_ENDBLOCKDATA = 349,
    KW_END_SUBROUTINE = 350,
    KW_ENDSUBROUTINE = 351,
    KW_END_FUNCTION = 352,
    KW_ENDFUNCTION = 353,
    KW_END_PROCEDURE = 354,
    KW_ENDPROCEDURE = 355,
    KW_END_ENUM = 356,
    KW_ENDENUM = 357,
    KW_END_SELECT = 358,
    KW_ENDSELECT = 359,
    KW_END_IF = 360,
    KW_ENDIF = 361,
    KW_END_INTERFACE = 362,
    KW_ENDINTERFACE = 363,
    KW_END_TYPE = 364,
    KW_ENDTYPE = 365,
    KW_END_ASSOCIATE = 366,
    KW_ENDASSOCIATE = 367,
    KW_END_FORALL = 368,
    KW_ENDFORALL = 369,
    KW_END_DO = 370,
    KW_ENDDO = 371,
    KW_END_WHERE = 372,
    KW_ENDWHERE = 373,
    KW_END_CRITICAL = 374,
    KW_ENDCRITICAL = 375,
    KW_END_FILE = 376,
    KW_ENDFILE = 377,
    KW_ENTRY = 378,
    KW_ENUM = 379,
    KW_ENUMERATOR = 380,
    KW_EQUIVALENCE = 381,
    KW_ERRMSG = 382,
    KW_ERROR = 383,
    KW_EVENT = 384,
    KW_EXIT = 385,
    KW_EXTENDS = 386,
    KW_EXTERNAL = 387,
    KW_FILE = 388,
    KW_FINAL = 389,
    KW_FLUSH = 390,
    KW_FORALL = 391,
    KW_FORMATTED = 392,
    KW_FUNCTION = 393,
    KW_GENERIC = 394,
    KW_GO = 395,
    KW_GOTO = 396,
    KW_IF = 397,
    KW_IMPLICIT = 398,
    KW_IMPORT = 399,
    KW_IMPURE = 400,
    KW_IN = 401,
    KW_INCLUDE = 402,
    KW_INOUT = 403,
    KW_IN_OUT = 404,
    KW_INQUIRE = 405,
    KW_INTEGER = 406,
    KW_INTENT = 407,
    KW_INTERFACE = 408,
    KW_INTRINSIC = 409,
    KW_IS = 410,
    KW_KIND = 411,
    KW_LEN = 412,
    KW_LOCAL = 413,
    KW_LOCAL_INIT = 414,
    KW_LOGICAL = 415,
    KW_MODULE = 416,
    KW_MOLD = 417,
    KW_NAME = 418,
    KW_NAMELIST = 419,
    KW_NOPASS = 420,
    KW_NON_INTRINSIC = 421,
    KW_NON_OVERRIDABLE = 422,
    KW_NON_RECURSIVE = 423,
    KW_NONE = 424,
    KW_NULLIFY = 425,
    KW_ONLY = 426,
    KW_OPEN = 427,
    KW_OPERATOR = 428,
    KW_OPTIONAL = 429,
    KW_OUT = 430,
    KW_PARAMETER = 431,
    KW_PASS = 432,
    KW_POINTER = 433,
    KW_POST = 434,
    KW_PRECISION = 435,
    KW_PRINT = 436,
    KW_PRIVATE = 437,
    KW_PROCEDURE = 438,
    KW_PROGRAM = 439,
    KW_PROTECTED = 440,
    KW_PUBLIC = 441,
    KW_PURE = 442,
    KW_QUIET = 443,
    KW_RANK = 444,
    KW_READ = 445,
    KW_REAL = 446,
    KW_RECURSIVE = 447,
    KW_REDUCE = 448,
    KW_RESULT = 449,
    KW_RETURN = 450,
    KW_REWIND = 451,
    KW_SAVE = 452,
    KW_SELECT = 453,
    KW_SELECT_CASE = 454,
    KW_SELECT_RANK = 455,
    KW_SELECT_TYPE = 456,
    KW_SEQUENCE = 457,
    KW_SHARED = 458,
    KW_SOURCE = 459,
    KW_STAT = 460,
    KW_STOP = 461,
    KW_SUBMODULE = 462,
    KW_SUBROUTINE = 463,
    KW_SYNC = 464,
    KW_TARGET = 465,
    KW_TEAM = 466,
    KW_TEAM_NUMBER = 467,
    KW_THEN = 468,
    KW_TO = 469,
    KW_TYPE = 470,
    KW_UNFORMATTED = 471,
    KW_USE = 472,
    KW_VALUE = 473,
    KW_VOLATILE = 474,
    KW_WAIT = 475,
    KW_WHERE = 476,
    KW_WHILE = 477,
    KW_WRITE = 478,
    UMINUS = 479
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
