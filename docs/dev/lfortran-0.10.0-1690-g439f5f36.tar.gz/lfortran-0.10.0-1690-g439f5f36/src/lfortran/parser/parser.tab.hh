/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_LABEL = 262,
    TK_REAL = 263,
    TK_BOZ_CONSTANT = 264,
    TK_PLUS = 265,
    TK_MINUS = 266,
    TK_STAR = 267,
    TK_SLASH = 268,
    TK_COLON = 269,
    TK_SEMICOLON = 270,
    TK_COMMA = 271,
    TK_EQUAL = 272,
    TK_LPAREN = 273,
    TK_RPAREN = 274,
    TK_LBRACKET = 275,
    TK_RBRACKET = 276,
    TK_RBRACKET_OLD = 277,
    TK_PERCENT = 278,
    TK_VBAR = 279,
    TK_STRING = 280,
    TK_COMMENT = 281,
    TK_DBL_DOT = 282,
    TK_DBL_COLON = 283,
    TK_POW = 284,
    TK_CONCAT = 285,
    TK_ARROW = 286,
    TK_EQ = 287,
    TK_NE = 288,
    TK_LT = 289,
    TK_LE = 290,
    TK_GT = 291,
    TK_GE = 292,
    TK_NOT = 293,
    TK_AND = 294,
    TK_OR = 295,
    TK_EQV = 296,
    TK_NEQV = 297,
    TK_TRUE = 298,
    TK_FALSE = 299,
    TK_FORMAT = 300,
    KW_ABSTRACT = 301,
    KW_ALL = 302,
    KW_ALLOCATABLE = 303,
    KW_ALLOCATE = 304,
    KW_ASSIGNMENT = 305,
    KW_ASSOCIATE = 306,
    KW_ASYNCHRONOUS = 307,
    KW_BACKSPACE = 308,
    KW_BIND = 309,
    KW_BLOCK = 310,
    KW_CALL = 311,
    KW_CASE = 312,
    KW_CHARACTER = 313,
    KW_CLASS = 314,
    KW_CLOSE = 315,
    KW_CODIMENSION = 316,
    KW_COMMON = 317,
    KW_COMPLEX = 318,
    KW_CONCURRENT = 319,
    KW_CONTAINS = 320,
    KW_CONTIGUOUS = 321,
    KW_CONTINUE = 322,
    KW_CRITICAL = 323,
    KW_CYCLE = 324,
    KW_DATA = 325,
    KW_DEALLOCATE = 326,
    KW_DEFAULT = 327,
    KW_DEFERRED = 328,
    KW_DIMENSION = 329,
    KW_DO = 330,
    KW_DOWHILE = 331,
    KW_DOUBLE = 332,
    KW_DOUBLE_PRECISION = 333,
    KW_ELEMENTAL = 334,
    KW_ELSE = 335,
    KW_ELSEIF = 336,
    KW_ELSEWHERE = 337,
    KW_END = 338,
    KW_END_IF = 339,
    KW_ENDIF = 340,
    KW_END_INTERFACE = 341,
    KW_ENDINTERFACE = 342,
    KW_ENDTYPE = 343,
    KW_END_FORALL = 344,
    KW_ENDFORALL = 345,
    KW_END_DO = 346,
    KW_ENDDO = 347,
    KW_END_WHERE = 348,
    KW_ENDWHERE = 349,
    KW_ENTRY = 350,
    KW_ENUM = 351,
    KW_ENUMERATOR = 352,
    KW_EQUIVALENCE = 353,
    KW_ERRMSG = 354,
    KW_ERROR = 355,
    KW_EVENT = 356,
    KW_EXIT = 357,
    KW_EXTENDS = 358,
    KW_EXTERNAL = 359,
    KW_FILE = 360,
    KW_FINAL = 361,
    KW_FLUSH = 362,
    KW_FORALL = 363,
    KW_FORMATTED = 364,
    KW_FUNCTION = 365,
    KW_GENERIC = 366,
    KW_GO = 367,
    KW_GOTO = 368,
    KW_IF = 369,
    KW_IMPLICIT = 370,
    KW_IMPORT = 371,
    KW_IMPURE = 372,
    KW_IN = 373,
    KW_INCLUDE = 374,
    KW_INOUT = 375,
    KW_IN_OUT = 376,
    KW_INQUIRE = 377,
    KW_INTEGER = 378,
    KW_INTENT = 379,
    KW_INTERFACE = 380,
    KW_INTRINSIC = 381,
    KW_IS = 382,
    KW_KIND = 383,
    KW_LEN = 384,
    KW_LOCAL = 385,
    KW_LOCAL_INIT = 386,
    KW_LOGICAL = 387,
    KW_MODULE = 388,
    KW_MOLD = 389,
    KW_NAME = 390,
    KW_NAMELIST = 391,
    KW_NOPASS = 392,
    KW_NON_INTRINSIC = 393,
    KW_NON_OVERRIDABLE = 394,
    KW_NON_RECURSIVE = 395,
    KW_NONE = 396,
    KW_NULLIFY = 397,
    KW_ONLY = 398,
    KW_OPEN = 399,
    KW_OPERATOR = 400,
    KW_OPTIONAL = 401,
    KW_OUT = 402,
    KW_PARAMETER = 403,
    KW_PASS = 404,
    KW_POINTER = 405,
    KW_POST = 406,
    KW_PRECISION = 407,
    KW_PRINT = 408,
    KW_PRIVATE = 409,
    KW_PROCEDURE = 410,
    KW_PROGRAM = 411,
    KW_PROTECTED = 412,
    KW_PUBLIC = 413,
    KW_PURE = 414,
    KW_QUIET = 415,
    KW_RANK = 416,
    KW_READ = 417,
    KW_REAL = 418,
    KW_RECURSIVE = 419,
    KW_REDUCE = 420,
    KW_RESULT = 421,
    KW_RETURN = 422,
    KW_REWIND = 423,
    KW_SAVE = 424,
    KW_SELECT = 425,
    KW_SELECT_CASE = 426,
    KW_SELECT_RANK = 427,
    KW_SELECT_TYPE = 428,
    KW_SEQUENCE = 429,
    KW_SHARED = 430,
    KW_SOURCE = 431,
    KW_STAT = 432,
    KW_STOP = 433,
    KW_SUBMODULE = 434,
    KW_SUBROUTINE = 435,
    KW_SYNC = 436,
    KW_TARGET = 437,
    KW_TEAM = 438,
    KW_TEAM_NUMBER = 439,
    KW_THEN = 440,
    KW_TO = 441,
    KW_TYPE = 442,
    KW_UNFORMATTED = 443,
    KW_USE = 444,
    KW_VALUE = 445,
    KW_VOLATILE = 446,
    KW_WAIT = 447,
    KW_WHERE = 448,
    KW_WHILE = 449,
    KW_WRITE = 450,
    UMINUS = 451
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
