/* A Bison parser, made by GNU Bison 3.3.2.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2019 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_PARSER_TAB_HH_INCLUDED
# define YY_YY_PARSER_TAB_HH_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 25 "parser.yy" /* glr.c:197  */

#include <lfortran/parser/parser.h>

#line 48 "parser.tab.hh" /* glr.c:197  */

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    END_OF_FILE = 0,
    TK_NEWLINE = 258,
    TK_NAME = 259,
    TK_DEF_OP = 260,
    TK_INTEGER = 261,
    TK_REAL = 262,
    TK_BOZ_CONSTANT = 263,
    TK_PLUS = 264,
    TK_MINUS = 265,
    TK_STAR = 266,
    TK_SLASH = 267,
    TK_COLON = 268,
    TK_SEMICOLON = 269,
    TK_COMMA = 270,
    TK_EQUAL = 271,
    TK_LPAREN = 272,
    TK_RPAREN = 273,
    TK_LBRACKET = 274,
    TK_RBRACKET = 275,
    TK_RBRACKET_OLD = 276,
    TK_PERCENT = 277,
    TK_VBAR = 278,
    TK_STRING = 279,
    TK_COMMENT = 280,
    TK_DBL_DOT = 281,
    TK_DBL_COLON = 282,
    TK_POW = 283,
    TK_CONCAT = 284,
    TK_ARROW = 285,
    TK_EQ = 286,
    TK_NE = 287,
    TK_LT = 288,
    TK_LE = 289,
    TK_GT = 290,
    TK_GE = 291,
    TK_NOT = 292,
    TK_AND = 293,
    TK_OR = 294,
    TK_EQV = 295,
    TK_NEQV = 296,
    TK_TRUE = 297,
    TK_FALSE = 298,
    KW_ABSTRACT = 299,
    KW_ALL = 300,
    KW_ALLOCATABLE = 301,
    KW_ALLOCATE = 302,
    KW_ASSIGNMENT = 303,
    KW_ASSOCIATE = 304,
    KW_ASYNCHRONOUS = 305,
    KW_BACKSPACE = 306,
    KW_BIND = 307,
    KW_BLOCK = 308,
    KW_CALL = 309,
    KW_CASE = 310,
    KW_CHARACTER = 311,
    KW_CLASS = 312,
    KW_CLOSE = 313,
    KW_CODIMENSION = 314,
    KW_COMMON = 315,
    KW_COMPLEX = 316,
    KW_CONCURRENT = 317,
    KW_CONTAINS = 318,
    KW_CONTIGUOUS = 319,
    KW_CONTINUE = 320,
    KW_CRITICAL = 321,
    KW_CYCLE = 322,
    KW_DATA = 323,
    KW_DEALLOCATE = 324,
    KW_DEFAULT = 325,
    KW_DEFERRED = 326,
    KW_DIMENSION = 327,
    KW_DO = 328,
    KW_DOWHILE = 329,
    KW_DOUBLE = 330,
    KW_ELEMENTAL = 331,
    KW_ELSE = 332,
    KW_ELSEIF = 333,
    KW_ELSEWHERE = 334,
    KW_END = 335,
    KW_END_IF = 336,
    KW_ENDIF = 337,
    KW_END_INTERFACE = 338,
    KW_ENDINTERFACE = 339,
    KW_END_FORALL = 340,
    KW_ENDFORALL = 341,
    KW_END_DO = 342,
    KW_ENDDO = 343,
    KW_END_WHERE = 344,
    KW_ENDWHERE = 345,
    KW_ENTRY = 346,
    KW_ENUM = 347,
    KW_ENUMERATOR = 348,
    KW_EQUIVALENCE = 349,
    KW_ERRMSG = 350,
    KW_ERROR = 351,
    KW_EXIT = 352,
    KW_EXTENDS = 353,
    KW_EXTERNAL = 354,
    KW_FILE = 355,
    KW_FINAL = 356,
    KW_FLUSH = 357,
    KW_FORALL = 358,
    KW_FORMAT = 359,
    KW_FORMATTED = 360,
    KW_FUNCTION = 361,
    KW_GENERIC = 362,
    KW_GO = 363,
    KW_IF = 364,
    KW_IMPLICIT = 365,
    KW_IMPORT = 366,
    KW_IMPURE = 367,
    KW_IN = 368,
    KW_INCLUDE = 369,
    KW_INOUT = 370,
    KW_IN_OUT = 371,
    KW_INQUIRE = 372,
    KW_INTEGER = 373,
    KW_INTENT = 374,
    KW_INTERFACE = 375,
    KW_INTRINSIC = 376,
    KW_IS = 377,
    KW_KIND = 378,
    KW_LEN = 379,
    KW_LOCAL = 380,
    KW_LOCAL_INIT = 381,
    KW_LOGICAL = 382,
    KW_MODULE = 383,
    KW_MOLD = 384,
    KW_NAME = 385,
    KW_NAMELIST = 386,
    KW_NOPASS = 387,
    KW_NON_INTRINSIC = 388,
    KW_NON_OVERRIDABLE = 389,
    KW_NON_RECURSIVE = 390,
    KW_NONE = 391,
    KW_NULLIFY = 392,
    KW_ONLY = 393,
    KW_OPEN = 394,
    KW_OPERATOR = 395,
    KW_OPTIONAL = 396,
    KW_OUT = 397,
    KW_PARAMETER = 398,
    KW_PASS = 399,
    KW_POINTER = 400,
    KW_PRECISION = 401,
    KW_PRINT = 402,
    KW_PRIVATE = 403,
    KW_PROCEDURE = 404,
    KW_PROGRAM = 405,
    KW_PROTECTED = 406,
    KW_PUBLIC = 407,
    KW_PURE = 408,
    KW_QUIET = 409,
    KW_RANK = 410,
    KW_READ = 411,
    KW_REAL = 412,
    KW_RECURSIVE = 413,
    KW_REDUCE = 414,
    KW_RESULT = 415,
    KW_RETURN = 416,
    KW_REWIND = 417,
    KW_SAVE = 418,
    KW_SELECT = 419,
    KW_SEQUENCE = 420,
    KW_SHARED = 421,
    KW_SOURCE = 422,
    KW_STAT = 423,
    KW_STOP = 424,
    KW_SUBMODULE = 425,
    KW_SUBROUTINE = 426,
    KW_TARGET = 427,
    KW_TEAM = 428,
    KW_TEAM_NUMBER = 429,
    KW_THEN = 430,
    KW_TO = 431,
    KW_TYPE = 432,
    KW_UNFORMATTED = 433,
    KW_USE = 434,
    KW_VALUE = 435,
    KW_VOLATILE = 436,
    KW_WHERE = 437,
    KW_WHILE = 438,
    KW_WRITE = 439,
    UMINUS = 440
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef LFortran::YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif



int yyparse (LFortran::Parser &p);

#endif /* !YY_YY_PARSER_TAB_HH_INCLUDED  */
